library(testthat)
library(feedr)

test_check("feedr")
